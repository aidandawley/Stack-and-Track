package com.stacktrack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StackAndTrackApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
